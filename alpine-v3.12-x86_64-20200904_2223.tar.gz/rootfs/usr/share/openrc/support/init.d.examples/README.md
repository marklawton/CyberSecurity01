Example OpenRC Service Scripts
##############################

The service scripts in this directory are meant as examples only.
They are not installed by default as the scripts will need tweaking on a
per distro basis. They are also non essential to the operation of the system.
