## Dell SupportAssist RCE Proof of Concept

This is the proof of concept source code for CVE-2019-3719, a vulnerability in most of all Dell machines that allowed for remote code execution. See the blog post [here](https://d4stiny.github.io/Remote-Code-Execution-on-most-Dell-computers/).

## Usage

```
python3 main.py [Interface Name] [Victim IP] [Gateway IP] [Payload Filename]
```
